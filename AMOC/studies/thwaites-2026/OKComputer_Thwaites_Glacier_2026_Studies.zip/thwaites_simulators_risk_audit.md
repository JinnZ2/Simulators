# Thwaites Glacier September-2026 Papers × JinnZ2/Simulators
## Risk-management-weighted audit (worst-case planning, not conservative averaging)

All tools below were **actually cloned and run** from `github.com/JinnZ2/Simulators` (2026-09-23).
Where a tool takes structured inputs, each paper was encoded as an input file and executed.
"Risk-weighted" here follows the repo's own rule: report the band, plan against the short end;
treat committed loss as the floor, not the scenario.

---

## Results map

| Paper | Tools run | Headline output |
|---|---|---|
| Goldberg et al. (ice-sheet modeling) | `climate-modeling` audit suite; `declared-frame` | **7/7 built audits FAIL**: smooth models are blind to threshold+memory cascades |
| Killingbeck et al. (MT groundwater) | `closure-cost` (instrument branch); `declared-frame`; `measurement-fork` | Intermediary (resistivity) is the reading; pore pressure never sampled |
| Phạm (glacial earthquakes) | `instrument-bias-sims` S1; `declared-frame` | Event-sampled catalog has **null share 0.0000** — baseline reconstructed from events alone |
| Pierce et al. (radar bed) | `measurement-fork`; `declared-frame` | Radar/MT/seismic arms **share no quantity at all** — no cross-validation exists |
| Bradley et al. (committed loss) | `closure-cost` (event branch); `reservoir-chain-coupling`; `declared-frame` | "No melt → no loss" was a **closed variable**; coupled chain breaches **4/4 nodes** the per-node view clears |

---

## 1. Goldberg, Holland & Naughten — ice-sheet modeling / sea-level projections

**Tools: `climate-modeling` audit suite + `declared-frame`.**

The climate-modeling suite exists to catch *cascade-speed blindness* — "a smooth, memoryless,
Gaussian-driven model predicts collapse in fifty years and reality does it in five." Run result:

```
Cascade Speed Blindness    FAIL  rmse=307017.9   (threshold+feedback+memory+fat tails)
Stationarity Assumption    FAIL  final_biomass_error=99.97
Phase Change Blindness     FAIL  final_biomass_error=73.17
Missing Feedback           FAIL  final_biomass_error=248944.6
Omitted Variable           FAIL  final_biomass_error=76.05
Data Aggregation Error     FAIL  rmse=7.35
Missing Positive Feedback  FAIL  final_biomass_error=283254.5
SUMMARY: 0 pass, 7 fail
```

Every failure mode the suite flags has a direct analogue in the Goldberg paper's own finding:
**initialization dominates the 21st century** = the model's near-term answer is set by an
inherited state, not by measured physics (the suite's Stationarity/Omitted-Variable failures);
**forcing dominates later** = the regime where the model is best validated is the regime that
matters least for people alive now.

The declared-frame check pins the framing:
- **horizon**: the headline "2.6 mm/yr by 2200" is scored 175 years out; the 2026–2100 window — the planning horizon of every living structure — is the initialization-dominated window the model is *least* informative in.
- **boundary**: modeled ice volume only; MICI-style cliff physics, subglacial hydrology feedbacks (the Killingbeck/Pierce territory), and the downstream WAIS buttressing chain are outside the accounting.
- **who_counts**: global mean SLE. No coastline, no time-of-arrival distribution; the aggregate absorbs the variance that risk management lives on.

**Risk read:** treat 2.6 mm/yr by 2200 as a *floor with a smooth-model bias*, not a ceiling.
The suite's flagship result is that smooth models systematically *understate* cascade speed when
threshold, feedback, and memory are present — and Thwaites is the canonical threshold+memory system.

---

## 2. Killingbeck et al. — subglacial groundwater via magnetotellurics

**Tools: `closure-cost` (instrument branch), `measurement-fork`, `declared-frame`.**

Encoded as a closure-cost case (`thwaites-killingbeck-mt`), branch **instrument**:

> A reliable intermediary becomes the reading, and the underlying quantity stops being sampled
> directly. Failure clusters where the intermediary has a *long correct record* — here it is worse:
> reliance with **no** direct record at all. There is no basin-scale borehole validation of the MT
> inversion beneath Thwaites.

Checker output: `variable_state=not_assessed`, `signal relied_on_as_reading=true`. The quantity
that actually controls basal sliding — **pore water pressure at the ice-bed interface** — sits
outside the instrument's constitution. MT reads bulk resistivity, a non-unique mixture of water
content, salinity, and temperature: one resistivity curve, many possible subglacial worlds.

**Risk read:** "high resistivity (>10 Ωm), distinct regime" does **not** exclude a thin, saline,
high-pressure water film — exactly the configuration that controls sliding. And the frame is a
**snapshot**: one survey epoch over a dynamic hydrological system with sub-seasonal variability.
Risk-weighted: this paper narrows the *map*, not the *risk*. The distinct-regime finding cuts both
ways — a basin unlike other Antarctic sites is a basin where transfer of calibrations from those
sites is unlicensed.

---

## 3. Phạm — 245 hidden glacial earthquakes

**Tools: `instrument-bias-sims` S1 (event-sampled observation), `declared-frame`.**

S1 models two observers of one system: A samples every tick, B samples only when something is
happening. Run output:

```
f        true null    B null
0.001    0.9989       0.0000
0.200    0.7984       0.0000
```

An event-triggered observer's record contains **no null at all** — at f=0.001 the system is 99.9%
quiet and the event catalog reports a composition with zero quiet in it. The distortion is a
*product*: event triggering removes the null baseline, then cost weighting re-weights what is left.

This is the exact constitution of a seismic detection catalog: 245 events over 2010–2023 are the
events **above detection threshold** of a network whose coverage and sensitivity changed over the
window. "Peak activity coinciding with accelerated ice flow" is computed on the detected record;
the pre-instrument baseline does not exist.

**Risk read:** two directions, both unfavorable to complacency.
1. The catalog *understates*: sub-threshold calving and aseismic slip are outside the accounting,
   so total edge instability is greater than 245 events.
2. The trend is *unverifiable as stated*: rising event counts over 2010–2023 confound glacier
   acceleration with network improvement. Risk-weighted posture: assume the physical trend is real
   (it has a mechanism — capsizing bergs at an accelerating margin) and treat the catalog as a
   lower bound, while refusing to use the apparent *calm early years* as any evidence of stability.

---

## 4. Pierce et al. — radar modeling of the bed

**Tools: `measurement-fork`, `declared-frame`.**

A full three-arm measurement-fork spec (`thwaites_subglacial`) was built covering the radar, MT,
and seismic instrument families plus the observing-program coupling, and run through `compare.py`:

```
arm conventional    8 probes
arm coupling       12 probes
arm widen          14 probes

SAME QUANTITY, DIFFERENT ROUTE
  none -- the arms share no quantity at all.
  That is itself a finding: the designs do not overlap,
  so no existing result speaks to the coupling questions.
```

**This is the cross-paper structural finding.** Pierce's radar, Killingbeck's MT, and Phạm's
seismology are three instruments reading three disjoint proxies of one system. There is no shared
quantity — no cell where two instruments measure the same thing by different routes — so
*no published result from any arm can confirm or refute any other*, and the one variable that
governs sliding (pore pressure) is in the residual set of all three.

On the paper itself, the declared-frame check flags the load-bearing sentence: "homogeneous
substrate under fast-moving western regions" is an **instrument-resolution statement that reads as
a property statement**. Smooth to radar at survey-line spacing ≠ smooth at the scale of basal
hydrology. The risk-relevant cell — the fast-moving region — is precisely the one with the least
resolved bed.

**Risk read:** the bed beneath the fastest ice is the least characterized; heterogeneity is the
finding where the ice is slow, homogeneity (read: resolution floor) where it is fast. Plan as if
the western region's basal conditions are *unknown*, not *favorable*.

---

## 5. Bradley et al. — mass loss continues without ocean melting

**Tools: `closure-cost` (event branch), `reservoir-chain-coupling`, `declared-frame`.**

Encoded as a closure-cost event-branch case (`thwaites-bradley-committed-loss`). The closed
variable: **"mass loss requires ocean melting."** Checker output:

```
VARIABLE  closed
INFORMATION AVAILABILITY  present
PROCEDURE GAP RIVAL: collapsed into closure  yes
```

Availability `present` + variable `closed` means the tool's core test fires: **the procedure gap
(no committed-loss planning) is ruled out as an information problem** — MISI theory and internal
dynamics literature existed for decades; the handling class was never acquired because the premise
said removing the driver removes the loss. This is the repo's central claim confirmed on this case:
response failure tracks prior closure, not event severity, not information availability.

Then the chain. Bradley's 150-year committed loss *is* the antecedent pool in
`reservoir-chain-coupling`'s operator swap: per-glacier assessment evaluates `max(new_forcing,
committed_state)`; coupled physics evaluates `new_forcing + committed_state`. Run on a declared
synthetic Thwaites→WAIS chain (units arbitrary and labeled):

```
RUN 1 per-glacier (max): breach set []
RUN 2 coupled (sum):     breach set [grounding_line, eastern_shelf, WAIS_interior, coastal_delivery]
VERDICT: LOAD-BEARING: coupled breaches 4 node(s) independent does not
independent-only: [] (must be empty — the bias is one-sided, always understating)

node                       max      sum
Thwaites_grounding_line   4.20     9.00  BREACH
Thwaites_eastern_shelf    2.94    12.00  BREACH
WAIS_interior_basins      2.06    15.00  BREACH
coastal_SLR_delivery      1.44    18.00  BREACH
```

The disagreement compounds downstream: each breach raises the load into the next node. A one-node
study (any single-glacier assessment) structurally cannot produce this.

**Risk read:** the design-basis number for adaptation is not "melt-driven loss under scenario X" but
"the committed component alone." Under zero melt the loss runs 150 years — past every governance,
infrastructure, and insurance horizon. Mitigation success does not retire this hazard. And every
per-glacier or per-sector assessment that ignores the committed antecedent state understates the
chain, with the error's sign fixed: always toward "safer than it is."

---

## Cross-paper synthesis (the risk-management view)

1. **The committed pool is the load-bearing input.** Bradley supplies the antecedent state;
   Goldberg supplies the arriving wave; the operator swap says combining them by `max` instead of
   `sum` is the standard assessment error, and it never overstates.
2. **No instrument reads the controlling variable.** Radar (Pierce), MT (Killingbeck), seismic
   (Phạm) share no quantity (measurement-fork, run result) and none reads pore pressure. The
   fastest-flowing region has the least-resolved bed.
3. **The event record has no baseline.** Phạm's catalog is event-triggered (S1: null share 0.0000);
   calm in the record is not calm in the glacier.
4. **The smooth-model bias is measured, not conjectured.** 7/7 climate-modeling audits FAIL in the
   direction of understated cascade speed — plan on the short end of every band.
5. **The failure was closure, not information.** Closure-cost: availability ruled out the
   procedure-gap rival. The handling class for committed loss does not exist because the premise
   was closed, and it must now be built under time pressure.

## Drafted gap-markers entries (schema-conformant)

```
GAP_ID   THW-01
DOMAIN   glaciology / coastal adaptation
STATE    unowned
WHAT_EXISTS  committed-loss magnitude (Bradley 2026); SLR ensembles (Goldberg 2026)
WHAT_IS_MISSING  any party whose scope covers translating committed glacier loss
                 into mandatory minimum design basis for coastal infrastructure
ENTRY_POINT  national adaptation design codes: does any cite committed ice loss as floor?
KIND     boundary-artifact

GAP_ID   THW-02
DOMAIN   radar glaciology / magnetotellurics / borehole hydrology
STATE    assembly
WHAT_EXISTS  basin-scale radar (Pierce 2026), MT (Killingbeck 2026)
WHAT_IS_MISSING  a shared quantity: any cell where two instruments measure the same
                 subglacial variable by different routes; pore pressure unmeasured by all
ENTRY_POINT  co-locate one deep borehole with existing radar/MT lines
KIND     knowledge (measurement genuinely absent) + boundary-artifact (funding by instrument)

GAP_ID   THW-03
DOMAIN   seismology / ice-flow dynamics
STATE    unasked
WHAT_EXISTS  13-year seismic catalog (Phạm 2026), continuous satellite velocity
WHAT_IS_MISSING  the question posed with detection-threshold correction: event rate
                 per unit detection sensitivity, not per calendar year
ENTRY_POINT  recompute the catalog trend against network sensitivity history
KIND     boundary-artifact (data exists, collected for another purpose)
```

## Observable-indicator analogue (`observable-indicator-rules`)

The OIR run confirmed its standing finding — the pipeline's stability check is a **miss filter,
blind to false alarms** (measured false-alarm rate 0.5 passes with miss rate 0.0). Applied here:
any Thwaites-derived public warning rule ("IF grounding line retreats past X THEN revise coastal
codes") must carry **both** a miss rate and a false-alarm rate on the card, and the band's short
end is what gets planned against. The router (coupled ice-ocean solve) is the non-phone term;
everything downstream of it — the indicator card a coastal authority or household evaluates on
sight — is cheap, and currently nobody owns building it (THW-01).

---

### Method note
Repo cloned 2026-09-23; tools run unmodified except inputs: two closure-cost case files, five
declared-frame blocks, one measurement-fork spec, one chain driver using the repo's own `Node`/
`compare` API with synthetic labeled values. No tool output was edited. Synthetic chain values are
declared arbitrary units; the claim they carry is the *operator*, not the magnitudes — per the
repo's own discipline.
